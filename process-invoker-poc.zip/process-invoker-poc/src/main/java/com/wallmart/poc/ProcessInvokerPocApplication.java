package com.wallmart.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcessInvokerPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessInvokerPocApplication.class, args);
	}

}
