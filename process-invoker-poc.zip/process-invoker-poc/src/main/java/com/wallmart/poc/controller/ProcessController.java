package com.wallmart.poc.controller;

import com.wallmart.poc.service.ProcessService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/process")
public class ProcessController {

    private ProcessService processService;

    public ProcessController(ProcessService processService) {
        this.processService = processService;
    }

    @GetMapping("/invoke")
    public ResponseEntity<String> invokeProcess() {
        System.out.print(processService.invokeProcess());
        return ResponseEntity.ok("Process Has been triggered");
    }
}
