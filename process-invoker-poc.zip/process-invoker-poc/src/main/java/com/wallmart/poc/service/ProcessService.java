package com.wallmart.poc.service;

import org.springframework.stereotype.Service;

@Service
public class ProcessService {

    public String invokeProcess() {
        return "Process Invoked";
    }
}
